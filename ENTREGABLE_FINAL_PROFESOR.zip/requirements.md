# MascotasLost&Found — requirements.md

> Metodología: Spec-Driven Development (SDD).
> Este documento es la fuente de verdad del MVP. Todo commit debe referenciar una sección (p.ej. `REQ-03`, `CU-02`).
> Estado: v1.41 (05/10/2026) — §8/§9 conservan pesos y umbrales; §41 documenta modos visuales, referencia temporal de demo, normalización lingüística y seed actual. Los REQ-UI numerados son cronológicos y los posteriores prevalecen (reversiones explicadas en PROMPT-LOG.md). Decisiones cerradas v1.0: 23/09/2026 (13/13). Stack: Streamlit + Python + SQLite; ejecución local y demo opcional en Streamlit Cloud (filesystem efímero).

## 1. Objetivo (REQ-01)

Construir un MVP funcional que centralice avisos de mascotas perdidas (`lost`) y encontradas (`found`) en un corpus propio y controlado, y sugiera **posibles coincidencias** a partir de imagen, descripción textual, ubicación y fecha.

El valor no es identificar con certeza, sino **priorizar candidatos** para que el dueño revise visualmente y contacte.

Principio transversal: **el sistema nunca afirma "es el mismo animal"**. Siempre muestra "posible coincidencia" con porcentaje y señales que la sustentan. El aviso legal vive en un único apartado del sidebar ("Este análisis no promete una coincidencia inequívoca respecto al animal buscado. Una imagen no permite confirmar la identidad, verifique en persona.").

## 2. Problema que resuelve (REQ-02)

Cuando una mascota se pierde, los avisos quedan dispersos en redes sociales y protectoras sin forma de cruzarlos automáticamente. El sistema centraliza avisos y propone cruces lost ↔ found.

## 3. Alcance del MVP — qué SÍ hace (REQ-03)

- REQ-03.1: Acepta cualquier animal doméstico (`dog | cat | other`), no solo perros/gatos.
- REQ-03.2: Permite registrar avisos `lost` y `found` con foto + texto libre + ubicación (lat/lng) + fechas.
- REQ-03.3: Normaliza todo aviso al esquema **Entidad Aviso** (ver §6).
- REQ-03.4: Ejecuta pipeline de 5 agentes: Ingestor → Vision Analyst → Matcher (+ Geo) → Notifier (ver §7).
- REQ-03.5: Calcula `score_total` con fórmula y pesos cerrados (ver §8).
- REQ-03.6: Muestra ranking de posibles coincidencias con desglose por señales y aplica umbrales §9.
- REQ-03.7: Visualiza candidatos en mapa interactivo por proximidad geográfica.
- REQ-03.8: Funciona con corpus demo propio de 15-20 avisos cargados manualmente (seed data).

## 4. Alcance — qué NO hace (límites explícitos, REQ-04)

- REQ-04.1: **NO scraping en vivo** de Facebook, Instagram, protectoras ni ninguna fuente externa. Queda fuera del MVP como ampliación futura documentable en memoria/slides, no a construir.
- REQ-04.2: **NO afirma identidad**: prohibido el literal "es el mismo animal" en UI, logs o notificaciones.
- REQ-04.3: NO autenticación multi-usuario ni roles. Excepción v1.1: UN único administrador con contraseña para moderación básica (ver REQ-11).
- REQ-04.4: NO app móvil nativa. Solo web MVP ejecutable en local + despliegue simple.
- REQ-04.5: NO Telegram/webhook real. Notifier MVP = panel/tabla en Streamlit + log (decisión 9, 23/09/2026).
- REQ-04.6: NO genera cartel PDF "SE BUSCA" en MVP (ampliación propuesta fuera de alcance salvo decisión explícita posterior).

## 5. Casos de uso principales

### CU-01 — Registrar aviso `lost`
Actor: dueño. Flujo: sube foto + descripción + ubicación + fechas + contacto obligatorio (al menos un dato: móvil, correo o red social; sin contacto no se publica) → Ingestor normaliza → Vision Analyst extrae atributos y embedding → se persiste → Matcher lo compara contra corpus `found` activos → se muestran coincidencias >=65% y se notifica si >=80%. Campos obligatorios marcados con `*` en el formulario.

### CU-02 — Registrar aviso `found`
Actor: persona que encuentra / protectora. Flujo simétrico a CU-01 (contacto también obligatorio, marcado con `*`), comparando contra corpus `lost` activos.

### CU-03 — Búsqueda de coincidencias (sin registrar)
Actor: dueño o quien avista. Flujo: elige canal (avistamientos si perdió, perdidos si encontró: quien busca es el caso inverso) + foto + zona + descripción → Matcher cruza SOLO contra ese canal → ranking ≥65% con desglose. Campos obligatorios marcados con `*` (canal, foto, animal, tamaño, color principal, descripción). Transitoria: no persiste ni escribe alertas. Haya coincidencia o no, el botón PUBLICAR AVISO lleva a CU-01/CU-02 con foto, zona, descriptivos y tipo ya precargados (el tipo se infiere del canal). Las alertas persistentes nacen del cruce al publicar.

### CU-04 — Revisar detalle de posible coincidencia
Actor: dueño. Ve lado a lado fotos, distancia km, diferencia días, atributos coincidentes/divergentes, y aviso legal de no-identidad. Decide contactar fuera del sistema.

### CU-05 — Resolver / expirar aviso / reencuentro
Actor: dueño. Marca aviso como `resolved` mediante botón manual "Marcar como resuelto". Función `expire_old()` marca `expired` a los avisos con más de 1 año sin cerrarse (invocable bajo demanda, sin cron; los resueltos viven en reencuentros y no expiran). Los no-`active` no entran en matching.
Actor: cualquiera que presencie el reencuentro. En VOLVIÓ A CASA selecciona el perdido y/o avistamiento que se resuelve, sube fotos del reencuentro y lo notifica: queda pendiente y el administrador lo valida (resuelve los avisos y cierra el caso visible) o lo rechaza (posible vandalismo: los avisos siguen activos). Toda decisión queda en `data/admin.log`.

Fuera de MVP: CU-07 ingesta automática externa, CU-08 chat asistente, CU-09 impresión cartel.

### CU-06 — Moderar avisos (administrador)
Actor: administrador autenticado (contraseña). Flujo: entra en el apartado Administración del sidebar → filtra por tipo/texto → elimina duplicados o vandalismo (con confirmación) o marca resueltos → la acción queda en `data/admin.log`.

## 6. Esquema de datos — Entidad Aviso (REQ-05)

Todo aviso persiste con esta forma (decisión cerrada, no modificar sin nueva spec):

```json
{
  "id": "uuid",
  "type": "lost | found",
  "animal": "dog | cat | other",
  "breed_guess": "string (opcional, generado por el agente de visión)",
  "color_primary": "string",
  "color_secondary": "string (opcional)",
  "markings": ["string"],
  "size": "small | medium | large",
  "has_collar": "boolean",
  "collar_description": "string (opcional)",
  "description_text": "string (texto libre del usuario)",
  "location": { "lat": "number", "lng": "number", "address_text": "string opcional" },
  "date_reported": "ISO 8601 datetime",
  "date_last_seen": "ISO 8601 datetime (opcional)",
  "image_url": "string",
  "image_embedding": "vector (generado por el agente de visión, no por el usuario)",
  "contact_info": "string (opcional)",
  "status": "active | resolved | expired"
}
```

Reglas derivadas:
- REQ-05.1: `id` UUID v4 generado en ingesta.
- REQ-05.2: `breed_guess` e `image_embedding` solo los escribe Vision Analyst, nunca el usuario. `image_embedding`: CLIP `openai/clip-vit-base-patch32`, 512 dimensiones.
- REQ-05.3: Solo `status=active` participa en Matcher.
- REQ-05.4: El cruce es siempre `lost ↔ found`, nunca `lost ↔ lost` ni `found ↔ found`.
- REQ-05.5: `image_url`: ruta local relativa `data/seed/images/<fichero>`.
- REQ-05.6: Conflicto Ingestor vs Vision (decisión 10): manda Vision Analyst para `color_primary` y resto de atributos visuales; `description_text` conserva intacto el texto original del usuario.
- REQ-05.7: Si `animal="other"`: obligatorios `color_primary`, `size`, `description_text`; opcionales `markings`, `has_collar`/`collar_description`; `breed_guess` se omite (NULL).
- REQ-05.8: `location`: lat/lng capturados por mapa clicable Leaflet; ciudad seed fija: Jerez de la Frontera.
- REQ-05.9: Idioma UI y textos: solo español.

## 7. Agentes y responsabilidades (REQ-06, decisión cerrada)

1. **Ingestor**: recibe foto + texto + ubicación + fecha de un aviso nuevo y lo normaliza al esquema §6. No calcula scores. Preserva `description_text` intacto.
2. **Vision Analyst**: procesa la imagen y extrae especie, raza aproximada, color, manchas, collar, tamaño, y genera el embedding visual CLIP 512-dim. Tiene precedencia sobre atributos visuales (decisión 10).
3. **Matcher**: compara un aviso contra el resto del corpus y calcula score (ver §8).
4. **Geo**: calcula distancia haversine y aplica `max(0, 1 - distancia_km / 15)`, radio_máximo fijo 15 km.
5. **Notifier**: si `notifica` (`score >= 80%` o puerta `visual >= 95%`), registra en tabla `notifications` + log y muestra destacada en panel Streamlit. Sin Telegram real.

> Conflicto Ingestor vs Vision resuelto 23/09/2026: manda Vision para `color_primary`; texto usuario intacto en `description_text`.

## 8. Motor de matching — fórmula y pesos (REQ-07)

```
score_total = (0.55 × similitud_visual)
            + (0.25 × similitud_texto)
            + (0.10 × proximidad_temporal)
            + (0.10 × proximidad_geográfica)
```

v1.2 (24/09/2026, decisión del alumno S51): geo 0.30→0.10, texto 0.20→0.30,
temporal 0.10→0.20. Motivo: la ubicación lejana penalizaba demasiado.

v1.40 (25/09/2026, decisión del alumno S108): visual 0.40→0.55, texto 0.30→0.25,
temporal 0.20→0.10, geo se queda en 0.10. Motivo: el visual manda más y
fecha/zona (ruido en Buscar) pesan menos. Descartado 0.60 de visual: la demo
E2E caía a 0.798 <0.80. Color/marcas se comparan normalizados (sin tildes,
mayúsculas ni espacios extra, con alias mínimos: café/canela/chocolate→marrón).

- `similitud_visual`: similitud coseno entre vectores del mismo espacio. Local con PyTorch usa CLIP `openai/clip-vit-base-patch32` 512-dim; Streamlit Cloud sin PyTorch usa MobileNetV3-Small ONNX 576-dim; histograma 8³ (512-dim) y hash son últimos recursos. Nunca se mezclan espacios en una comparación (S49).
- `proximidad_geográfica`: max(0, 1 - distancia_km / 15), radio_máximo fijo = 15 km.
- `similitud_texto`: 0.70 × estructurado + 0.30 × semántico. Estructurado: coincidencia campo a campo de `color_primary`, `markings`, `has_collar`, `size`. Semántico: coseno con `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` sobre `description_text`.
- `proximidad_temporal`: max(0, 1 - dias_diferencia / 30), ventana 30 días. Fecha usada: `date_last_seen` si existe, si no `date_reported`.

Restricciones: los 4 pesos suman 1.0. No se reponderan sin nueva spec.

## 9. Umbrales de notificación (REQ-08, `>=`)

v1.2 (24/09/2026, decisión del alumno S51): alerta 85%→80%.

- Score >= 80%: notificación automática (panel + log) + se muestra como "posible coincidencia" destacada.
- Puerta visual (v1.40 S108): visual >= 95% también notifica aunque el total no llegue (la misma foto siempre da 1.0; se reserva para imágenes casi idénticas).
- Score 65-79.99%: aparece en el listado, sin notificación.
- Score < 65%: no se muestra como coincidencia, pero queda indexado.

## 10. Requisitos no funcionales (REQ-09)

- REQ-09.1: Ejecución local en 1 comando documentado en README para que el profesor evalúe sin nube.
- REQ-09.2: Despliegue simple opcional (Streamlit Cloud / similar) con enlace en README.
- REQ-09.3: SQLite / ficheros locales para seed; sin servicios externos obligatorios.
- REQ-09.4: Explicabilidad: todo match muestra sus 4 sub-scores.
- REQ-09.5: Privacidad mínima: `contact_info` obligatorio al publicar (al menos un dato, v1.4 24/09/2026), visible solo en detalle.
- REQ-09.6: Trazabilidad SDD: commit → sección de spec.

## 11. Criterios de éxito del MVP (REQ-10)

- ÉXITO-01: Con seed de 15-20 avisos, un `lost` de prueba recupera al menos 1 `found` relevante >65% con desglose correcto.
- ÉXITO-02: Ninguna pantalla/log/notificación contiene "es el mismo animal".
- ÉXITO-03: Matcher respeta fórmula/pesos/umbrales auditables (test con vectores fijos).
- ÉXITO-04: Profesor ejecuta en local siguiendo README en <10 min sin claves obligatorias.
- ÉXITO-05: Repo GitHub con historial progresivo + PROMPT-LOG.md + sesiones Engram + informe reflexión.
- ÉXITO-06: Demo 5 min: registro → ranking → mapa → detalle explicable.

## 12. Administración (REQ-11, añadido v1.1)

- REQ-11.1: Un único administrador; acceso por contraseña configurada en Secrets `ADMIN_PASSWORD` (Cloud) o variable `HUELLAS_ADMIN_PASSWORD` (local, p. ej. `.streamlit/secrets.toml`). Sin contraseña configurada, la administración queda desactivada (v1.40 S113: se retiró el defecto local documentado por seguridad al ser repo público).
- REQ-11.2: Puede listar con filtros, eliminar (borra aviso + notificaciones ligadas + foto subida, nunca seed) y resolver.
- REQ-11.3: Toda acción se registra en `data/admin.log` con fecha.
- REQ-11.4: El admin puede editar cualquier campo del aviso (con validación del esquema y log de campos cambiados).
- REQ-11.5: El admin revisa los reencuentros pendientes (fotos + avisos): validar resuelve los avisos y publica el cierre; rechazar los deja activos.

## 14. Navegación e Inicio (REQ-UI-01..06, añadido v1.2 24/09/2026)

No toca matching, agentes, RAG ni BD (solo UI en `app.py` + nuevo `ui_home.py` puro).

- REQ-UI-01 — Pantalla Inicio por defecto: al abrir la app `session_state.page="inicio"`.
  Muestra hero + carrusel en movimiento + 3 contadores. El logo y el header quedan intactos.
  El hero no repite la ciudad (Jerez ya está en el header).
- REQ-UI-02 — Barra lateral, 5 elementos en este orden (v1.29 25/09/2026, antes 6):
  `INICIO` (botón rojo grande, icono casa Material, activo con barra blanca + fondo oscuro),
  `FUNCIONALIDADES` (plegable rojo, icono apps, único abierto por defecto: agrupa
  Publicar aviso + Búsqueda de coincidencias como botones secundarios negros
  tabulados a la derecha),
  `PUNTUALIZACIONES WEB` (plegable rojo, icono aviso: despliega Cómo puntúa + Aviso legal,
  ambos expanders cerrados hasta clicar, contenidos tabulados),
  (sin `DATOS DEMO` desde v1.29: la demo siempre está cargada; limpiar = avisar),
  `MÁS` (plegable rojo con `+`: despliega Protectoras y Tiempo en Jerez, también
  secundarios negros tabulados, con sus iconos),
  `ADMINISTRACIÓN` (plegable rojo, icono llave: panel tabulado con login + moderación +
  reencuentros).
  Sin Perdidos/Avistamientos/Volvió a casa en el sidebar (se llega vía Inicio).
  Plegables = botón rojo que alterna `session_state` (al abrir la app, solo
  FUNCIONALIDADES desplegada; la navegación reabre FUNCIONALIDADES +
  `initial_sidebar_state` en expanded). La auto-apertura del PANEL al cambiar de
  pestaña se descartó (v1.11): Streamlit no expone API y los trucos (iframe de
  componente o `st.html` con JS) quedan bloqueados por el sanitizador.
  Botones a todo el ancho (`block-container` con `padding` lateral
  mínimo). Sin caption de conteo bajo "Animales perdidos activos".
  Cambiar de sección es un rerun Streamlit: conserva `session_state` (no pierde filtros).
- REQ-UI-03 — CTAs en el hero de Inicio y agrupados en FUNCIONALIDADES del sidebar
  (v1.4 24/09/2026): `Publicar aviso` y `Búsqueda de coincidencias`, ambos rojo sólido
  `#E30613` idénticos y grandes (visibles en móvil).
  `Publicar` → `page="publicar"`; `Búsqueda` → `page="buscar"`.
- REQ-UI-04 — Estilo botones (solo CSS, sin librerías): esquinas 6px,
  `transition: transform .2s, background .2s`, hover con `translateX(3px)` + fondo
  `rgba(227,6,19,.85)`, sin aspecto de blog. Hero: los 2 CTAs en rojo sólido idéntico
  con pulso suave (anillo `::after` que se expande `scale 1 → 1.12,1.4` y se
  desvanece, `2.2s ease-out infinite`).
  Sidebar: botones principales rojos grandes (`#E30613`, texto `#FFFFFF`, `padding .95rem 1rem`,
  `1.08rem` negrita, juntos con `gap 6px`) y secundarios negros tabulados (`#23201B`,
  `margin-left 1.25rem`), con iconos Material, sin emojis, a todo el ancho
  (`block-container` con `padding` lateral mínimo). Sin estirado flex (v1.8: se probó
  en v1.7 y empeoraba la estética). Bocadillos `help=` + CSS sobre
  `[data-testid="stTooltipContent"]`: sin captura de puntero y auto-ocultado a los
  4s aunque Streamlit los deje pillados (v1.6).
- REQ-UI-05 — Hero Inicio: titular `ESTOS PELUDOS QUIEREN VOLVER A CASA` en 2 líneas con
  `fade-up` (una vez, `both .7s`, segunda línea con `delay .25s`); palabra `CASA` en rojo
  `#E30613` con subrayado que se dibuja (`::after` animado); corazón SVG con latido suave
  (`scale 1 → 1.25`, `1.4s infinite`); subtítulo `Mira quién te está esperando…`.
- REQ-UI-06 — Carrusel infinito + contadores con navegación interna (v1.4 24/09/2026):
  fotos de avisos `active` (`lost`+`found`), máx. 12 (más recientes por `date_reported`),
  tarjeta = foto + `Especie · color` + zona (`address_text`) + etiqueta `Perdido/Avistado`.
  NUNCA `contact_info`/teléfono (test dedicado). Foto en letterbox crema (`300×208`,
  animal entero centrado sin recortes, JPEG q65, data URI) con `st.cache_data(ttl=120)`.
  Movimiento continuo CSS marquee (`32s linear infinite`, pista duplicada `-50%`),
  pausa en hover, clic en tarjeta → `?aviso=<id>` → salta a su aviso y lo resalta.
  `@media (prefers-reduced-motion: reduce)`: sin animaciones.
  Vacío → estado con invitación a publicar el primero. Debajo, 3 contadores como
  `st.button` (navegación interna en la misma pestaña, sin pestañas externas):
  perdidos → `perdidos`, avistamientos → `encontrados`, reencuentros → `reencuentro`
  (`?page=` sigue soportado como deep-link de compatibilidad).

Restricciones: reutiliza paleta/tipografía/logo/fondo existentes (`#E30613/#23201B/#FFFFFF/
#F5F1EA/#57503F`, Inter+Montserrat); sin colores nuevos; animaciones solo CSS
(`st.markdown(unsafe_allow_html)` / `components.html`); sin dependencias nuevas.

## 15. Tanda UI v1.12 (24/09/2026, a petición del alumno; solo UI, sin tocar matching/agentes/RAG/BD)

- REQ-UI-07 — Mapa de Buscar: la leyenda dice AVISTAMIENTOS (nunca ENCONTRADOS) y
  muestra AMBOS lados (TU CASO + PERDIDOS + AVISTAMIENTOS). El mapa de zona es de
  referencia: pinta perdidos (azules) y avistamientos (verdes) con `pin_color()` vía
  `get_active_opuestos()` en dos `MarkerCluster`. El cruce sí va solo contra el canal
  elegido. `leyenda_mapa()` acepta `mostrar_perdidos/mostrar_avist` para el mapa de
  resultados (`render_mapa_avistados()` la infiere de los tipos visibles).
- REQ-UI-08 — Buscar se titula ANÁLISIS PRELIMINAR DE SIMILITUDES RESPECTO AL REGISTRO
  y se reenumera: 1. ¿Dónde buscas? · 2. Foto actual · 3. Zona · 4. Descripción ·
  5. Lanza la búsqueda.
- REQ-UI-09 — Barrido rojo continuo en los títulos de Publicar
  (`Publica un aviso de perdido o avistamiento`) y Buscar (REQ-UI-08): letras con
  degradado negro→rojo→negro que barre de izquierda a derecha y viceversa
  (`.huellas-barrido`, `huellas-sweep 3.2s ease-in-out infinite`).
- REQ-UI-10 — Renombres: `Animales perdidos activos` → MASCOTAS DESAPARECIDAS y
  `Avistamientos` → RASTROS COMPARTIDOS (subheaders + `stat_box` + infos).
- REQ-UI-11 — Huella roja de perímetro en MASCOTAS DESAPARECIDAS, RASTROS COMPARTIDOS y
  VOLVIÓ A CASA (`.huellas-perimetro` + `.huellas-perimetro-paw` con SVG de huella
  `#E30613`, `huellas-peri 6s linear infinite`, velocidad media).
- REQ-UI-12 — Fuera bocadillos: eliminado todo `help=` (hero, sidebar, sliders) + CSS de
  `stTooltipContent`, y fuera el `title=` del carrusel (`ui_home.build_carousel_html`)
  que repetía el texto en negro al pasar el cursor.
- Accesibilidad: `prefers-reduced-motion` apaga también `huellas-sweep` y `huellas-peri`.
- Regla CSS crítica (S76): las propiedades animadas por keyframes (`background-position`
  del barrido, `top/left` de la huella) van SIN `!important` en la base — con `!important`
  la base gana a los keyframes en la cascada y la animación queda congelada en el
  fotograma inicial (verificado en Edge headless: reloj avanzando, valores fijos).

## 16. Publicar con vida + cascada global (v1.13 25/09/2026, solo UI)

- REQ-UI-13 — Cascada global: en todas las pestañas, las hijas directas del bloque
  principal entran con fade-up escalonado de 60 ms (`huellas-cascade .45s`, delays
  0–.60 s, `both`). Juega una sola vez al montar (los reruns conservan el DOM).
- REQ-UI-14 — Foto en Publicar: zona con borde discontinuo rojo + huella flotante;
  al subir imagen, miniatura con línea de escaneo roja (~1,5 s, `huellas-scan`) y
  después la etiqueta "Foto analizada" (fade con retardo 1,5 s).
- REQ-UI-15 — Botón "Confirmar y publicar": pulso suave (anillo) cuando el
  formulario está completo; si faltan campos, se sacude (shake 400 ms, con remontaje
  por clave `confirm_pub_{n}` para que repita) y lista qué falta (`faltantes_publicar`
  pura y testeada en `ui_home.py`).
- REQ-UI-16 — Al publicar: bloque "Cruzando con N avisos…" con puntos que rebotan y
  barra de progreso (mínimo 1,5 s, real si tarda más). Con coincidencia ≥80%: tarjeta
  que entra deslizándose con anillo que barre 0→real y dígitos que ruedan 0→real
  (`steps(pct)`) + botón "Ver aviso y contactar". Sin coincidencia: check verde que se
  dibuja solo + "Te avisaremos si aparece algo".
- Regla CSS crítica (S77): NADA de `@property`/contadores CSS para el conteo — en
  Chromium `var()` dentro de `counter-reset` invalida la declaración (cae a `none`) y
  con `inherits:false` el SVG ni hereda: todo se quedaba en 0. Los keyframes se generan
  con valores FIJOS por tarjeta (`huellas-ringfill-<pct>`, `huellas-strip-<pct>` con
  pista interior `.huellas-track`: animar el propio contenedor con `overflow:hidden`
  desplaza la ventana entera y no se ve nada).

## 17. Obligatorios completos + foto despejada + autocompletado (v1.14 25/09/2026, solo UI)

- REQ-UI-17 — En Publicar, color principal y descripción pasan a obligatorios de verdad:
  etiqueta con `*`, validación en `faltantes_publicar()` (pulso/shake incluidos) y tests.
- REQ-UI-18 — Foto despejada: fuera la huella flotante y el caption
  "Sube una foto… (40%)"; el cuadro del uploader crece (`min-height:190px`) para ocupar
  el hueco.
- REQ-UI-19 — Autocompletado en Ubicación exacta (Publicar): al escribir (3+ letras),
  sugerencias clicables vía Nominatim (`sugerir_direcciones()`, caché 1 h, sesgo Jerez);
  elegir una centra el mapa. Sin red o sin texto, no aparece nada (sin romper).

## 18. Desplegable de sugerencias + etiqueta lateral (v1.15 25/09/2026, solo UI)

- REQ-UI-20 — Las sugerencias salen como lista emergente pegada al recuadro (filas
  blancas `addr_sug_{i}` con chincheta CSS y borde rojo en hover), no como radio:
  un toque centra el mapa. Se refrescan al confirmar el texto (límite de Streamlit:
  los widgets no emiten por cada tecla, solo al confirmar; sin JS).
- REQ-UI-21 — "Foto analizada" a la DERECHA de la imagen (fila flex `.huellas-scanrow`
  que aprovecha el hueco lateral), no debajo.

## 19. Ajustes foto + revert sugerencias (v1.16 25/09/2026, solo UI)

- REQ-UI-22 — "Foto analizada" más grande (1rem) y centrada en el hueco lateral
  (`.huellas-scanbadge` flex); imagen algo más pequeña (máx. 300px) con aire inferior
  (`.huellas-scanrow` con `margin-bottom`) para no rozar el cuadro de abajo.
- REQ-UI-23 — Revert total del autocompletado (REQ-UI-19/20): fuera sugerencias, CSS,
  `sugerir_direcciones()` y `short_addr()`; Ubicación exacta vuelve a botón de
  geocodificado + clic en mapa + ajuste manual.

## 21. Buscar con vida + Perdidos/Avistamientos (v1.18 25/09/2026, solo UI)

- REQ-UI-26 — Foto en Buscar: miniatura con línea de escaneo + esquinas de encuadre
  (`build_foto_scan_html()` con `esquinas=True`) y etiqueta "Foto lista".
- REQ-UI-27 — Mapa de Buscar: círculo rojo de 2 km (radio de búsqueda) alrededor de tu
  zona + chip de confirmación al elegir punto (chincheta que cae con rebote y anillo
  pulsante, una sola vez por clic).
- REQ-UI-28 — Botón "Buscar coincidencias": radar (anillos + barrido giratorio + pings,
  mínimo 1,5 s real) mientras procesa; si faltan campos, shake 400 ms + lista
  (`faltantes_buscar()` pura, remontaje `b_buscar_{n}`).
- REQ-UI-29 — Resultados en cascada (envoltorio `.huellas-res`, 80 ms por tarjeta):
  anillo que cuenta hasta el % real + 4 barras (Visual/Zona/Texto/Fecha, relleno
  600 ms con keyframes fijos `huellas-bar-<uid>-<k>`); la mejor, con borde rojo y
  pulso suave (`.huellas-res-top`). Fotos y desglose intactos debajo.
- REQ-UI-30 — Sin resultados: "Sin coincidencias por ahora" + "Guardar como aviso"
  (mismo prefill) con rebote suave continuo.
- REQ-UI-31 — Contacto oculto en Perdidos y Avistamientos: botón "Ver contacto" que lo
  despliega con transición de altura 300 ms (`bloque_contacto()` + `contacto_html()`
  escapado); nunca visible por defecto.
- REQ-UI-32 — Chip "N días perdido" con urgencia (verde ≤2, ámbar 3-6, rojo ≥7) desde
  la fecha efectiva.
- REQ-UI-33 — Etiqueta "Nuevo" con punto pulsante (<48 h).
- REQ-UI-34 — Avistamientos: mismo contacto bajo demanda y "Nuevo"; chip neutro
  "Visto hace N días" en vez del de urgencia.

## 22. Pulido Buscar/Publicar/Perdidos (v1.19 25/09/2026, solo UI)

- REQ-UI-35 — "Foto lista" en grande a la derecha de la foto (fila flex, como en
  Publicar) + relleno verde parpadeante consistente en ambas miniaturas
  (`.huellas-flash`, infinito suave).
- REQ-UI-36 — Fechas del seed aleatorias reproducibles entre el 25/08 y el 25/09
  (`make_seed.py` con semilla; la pareja E2E conserva las suyas) + `SEED_VERSION` 7;
  formato de muestra siempre DD/MM/AA (`fmt_corta()`, la BD sigue en ISO).
- REQ-UI-37 — Leyenda y chinchetas (ambos lados) también en el mapa de Publicar.
- REQ-UI-38 — Fix mapa Buscar: la dirección del clic se aplica ANTES de instanciar el
  widget (clave `q_addr_pending`; asignarla después reventaba) + caché 30 días en
  geocodificado directo e inverso (el mapa ya no se arrastra por la red).
- REQ-UI-39 — Contacto con `<details>` nativo: abre y recoge fluido (transición de
  filas 300 ms reversible) sin rerun; el resumén alterna Ver/Ocultar solo con CSS.

## 23. Insignia grande + destello + doble clic (v1.20 25/09/2026, solo UI)

- REQ-UI-40 — "Foto lista" en grande a la derecha (como "Foto analizada"):
  `badge_lateral_html()` con flecha roja hacia la foto (leve impulso) e insignia
  mayor (1.25rem).
- REQ-UI-41 — El destello verde vive DENTRO de las insignias (no sobre las fotos).
- REQ-UI-42 — Mapas: se indica clicar 2 veces para fijar el punto (verificado por
  el alumno: con una no basta).

## 25. Foto centrada, atrás honesto y reencuentros (v1.22 25/09/2026, solo UI)

- REQ-UI-47 — "Foto lista" sin insignia ni flecha: imagen centrada
  (`.huellas-scancenter`) equilibrando el hueco.
- REQ-UI-48 — Caption de Buscar acortado (sin la leyenda de colores; ya está en el mapa).
- REQ-UI-49 — Botón atrás: `?s=` refleja la sección y sirve como deep-link, pero el
  navegador NO recorre secciones (estado en sesión, `replaceState`): documentado como
  límite, sin regresión.
- REQ-UI-50 — Reencuentros en español (`placeholder="Elige una opción"` nativo).
- REQ-UI-51 — "Notificar reencuentro": shake + faltante si no hay caso elegido.
- REQ-UI-52 — "En revisión" con puntos animados (mínimo 1,5 s real).
- REQ-UI-53 — Fiesta: timeline Perdido→Encontrado→En casa (nodos con rebote, líneas
  que se dibujan) + sello "VOLVIÓ A CASA" (cae de 2.4 con -8°) + lluvia de corazones
  y huellas (`celebrate_search()`).
- REQ-UI-54 — Tarjeta de caso cerrado deslizante: foto, "Especie · color",
  "Volvió a casa tras N días" y corazón latiendo (`build_cerrado_card_html()`).
- REQ-UI-55 — Vacío: corazón latiendo + "Aún no hay reencuentros. Sé el primero
  en cerrar un caso."

## 27. Casos con lluvia/ruleta + nota (v1.24 25/09/2026, solo UI)

- REQ-UI-59 — Cerrados con lluvia de corazones (8, escalonados) + corazón latiendo;
  en revisión solo ruleta de carga (sin corazón).
- REQ-UI-60 — Tarjeta translúcida (`rgba(255,255,255,0.55)`, se ve el fondo).
- REQ-UI-61 — La nota del reencuentro va justo bajo "Especie · color" (dentro de
  la tarjeta, en cursiva).

## 31. Remates casos y contadores (v1.28 25/09/2026, solo UI)

- REQ-UI-73 — En revisión sin doble borde (tarjeta directa, como cerrados).
- REQ-UI-74 — En el formulario solo vista previa de lo subido (fuera el par lateral).
- REQ-UI-75 — Lluvia pareja en todo el ancho (reparto uniforme 2–98%).
- REQ-UI-76 — Contadores con texto negro en negrita y más altos (96px).

## 33. Mapas frescos, contadores chicos, lluvia densa y limpieza real (v1.30 25/09/2026, solo UI)

- REQ-UI-78 — Chinchetas siempre al día: claves de mapa con fingerprint
  (`huella_mapa()` con id+coords+estado); publicar/resolver/editar regenera.
- REQ-UI-79 — Contadores al tamaño anterior (se conserva negro/negrita).
- REQ-UI-80 — Lluvia de 36 corazones con reparto uniforme (sin líneas).
- REQ-UI-81 — "Empezar de cero" limpia TODO incluido el uploader (rotación de clave
  `re_fotos_{n}`/`pub_foto_{n}`: el borrado de clave no lo vacía) + test AppTest.

## 34. Limpieza total por época (v1.31 25/09/2026, solo UI)

- REQ-UI-82 — Los borrados de clave NO limpian widgets en navegador real (el frontal
  restaura valores; en AppTest sí funcionaban): todos los campos de Publicar y
  Reencuentro rotan con época (`pub_epoch`/`re_epoch`; el prefill escribe en la época
  vigente). Test AppTest con claves rotadas.

## 36. Sidebar igualado + leyenda con conteos (v1.33 25/09/2026, solo UI)

- REQ-UI-85 — Los 4 expanders secundarios (Cómo puntúa, Aviso legal, Protectoras,
  Tiempo) con la misma tabulación que PUBLICAR/BÚSQUEDA (claves `exp_*` + margen).
- REQ-UI-86 — Protectoras y Tiempo en Jerez como desplegables compactos DENTRO del
  sidebar, con el perrito animado (SVG con clases globales, sin `<style>` ni iframe).
- REQ-UI-87 — Leyenda con conteos en vivo ("PERDIDOS (6) · AVISTAMIENTOS (13)"):
  lo que no cabe en número se agrupa en clusters (se despliegan al clicar).

## 35. Sidebar uniforme + MÁS desplegable (v1.32 25/09/2026, solo UI)

- REQ-UI-83 — Puntualizaciones a todo ancho (fuera columnas 0.12/0.88): mismo tamaño
  y expansión que el resto de secundarios.
- REQ-UI-84 — Protectoras y Tiempo en Jerez como desplegables DENTRO del sidebar
  (compactos, adaptados al panel), en vez de páginas grandes.

## 32. Sin Datos demo (v1.29 25/09/2026, solo UI)

- REQ-UI-77 — Fuera `DATOS DEMO` del sidebar (botón + cargar seed + expirar) con su
  CSS: la demo siempre está instaurada (auto-carga al arrancar); limpiar = avisar.
  Sidebar de 5 elementos. Sin borrado a un clic: el wipe era irreversible.

## 37. Sidebar rematado + pie admin (v1.34 25/09/2026, solo UI)

- REQ-UI-88 — Publicar aviso otra vez negro (una edición había roto su selector).
- REQ-UI-89 — Cuadros de Cómo puntúa compactos (sin solapes en el panel).
- REQ-UI-90 — Protectoras/Tiempo inline con contraste (fondo claro) y perrito por
  iframe probado (el SVG por markdown no renderiza: sale como texto).
- REQ-UI-91 — Pie de admin tras divisor: avistamientos 7 días + urgentes ≥7 días,
  badge naranja pulsante "Estado del Servicio: MODO DEMO (Jerez)" e Instagram/paypal.

## 39. MÁS en negro + pie en sidebar (v1.36 25/09/2026, solo UI)

- REQ-UI-95 — Protectoras/Tiempo como el resto de secundarios (botón negro, letras
  blancas; fuera el experimento en claro).
- REQ-UI-96 — Métricas/soporte en el sidebar tras ADMINISTRACIÓN (siempre visible,
  no tras login): divisor + métricas + badge + redes/donar.

## 40. Líneas alternas + pie centrado (v1.37 25/09/2026, solo UI)

- REQ-UI-97 — Protectoras/Tiempo con líneas alternas blanco/rojo (`build_alt_list()`)
  y enlaces legibles.
- REQ-UI-98 — Pie centrado (métricas, badge, soporte), segundo divisor tras el badge
  y un solo enlace de donación.
- REQ-UI-99 — Badge contenido (punto 8px, texto .72rem, aire superior) y soporte en
  formato CONTACTO/URL con https rojos clicables (v1.38).
- REQ-UI-100 — Métricas compactas de sidebar (`stat_side()`) y soporte con URLs
  que parten (`huellas-sup` con `break-all`) (v1.39).

## 38. Contraste MÁS + puntúa vertical + pie visible (v1.35 25/09/2026, solo UI)

- REQ-UI-92 — Protectoras/Tiempo en claro entero (cabecera en negro sobre blanco):
  el selector por bloques fugaba a la cabecera y la dejaba ilegible.
- REQ-UI-93 — Cómo puntúa en vertical (1 columna de 4): fin de solapes en el panel.
- REQ-UI-94 — Pie de admin justo tras entrar (tras login/Salir): antes quedaba tras
  20 tarjetas, invisible sin scroll.

## 30. Velo visible + reencuentro completo (v1.27 25/09/2026, solo UI)

- REQ-UI-71 — Velo de contadores sin `!important` en `opacity` (la base con
  `!important` congelaba los keyframes: mismo bug S76; auditoría completa del CSS
  sin más casos vivos).
- REQ-UI-72 — Reencuentro: botón "Empezar de cero", limpieza total tras publicar,
  vista previa de subidas y par aviso+foto lado a lado; tarjetas con ambas fotos
  (aviso + prueba) y lluvia de 20 corazones.

## 29. Inicio vivo + expiración anual + lost_006 (v1.26 25/09/2026, solo UI)

- REQ-UI-66 — Contadores de Inicio con velo rojo parpadeante (relleno rojo↔blanco a
  velocidad media, `::after` con `huellas-fillblink 1.8s`).
- REQ-UI-67 — CTAs del hero con pulso de escala (encogen al 94% y vuelven, 2.4 s);
  fuera el anillo expansivo.
- REQ-UI-68 — Expiración a 1 año (`expire_old(365)` + botón); `lost_006` vuelve a
  perdidos activos (los resueltos viven en reencuentros) + SEED v9 (20 activos:
  7 perdidos + 13 avistamientos).
- REQ-UI-69 — Segunda etiqueta del carrusel en bloque (sin cortes).
- REQ-UI-70 — Gestor de reencuentros arriba del admin (subheaders + abierto por
  defecto): visible sin scroll.

## 28. Admin fluida + reencuentros + 3 demo + carrusel (v1.25 25/09/2026)

- REQ-UI-62 — Fotos del admin fluidas (`use_container_width` + guarda CSS): se adaptan
  al sidebar plegado o ampliado, sin desbordar.
- REQ-UI-63 — Gestor de reencuentros en Administración: filtro por estado
  (pendientes/validados/rechazados/todos), fotos + avisos + nota visibles, validar /
  rechazar (pendientes) y eliminar con confirmación (`delete_reencuentro()`; los
  avisos quedan intactos; todo en `admin.log`). REQ-11.5 extendido.
- REQ-UI-64 — 3 animales demo para reencuentros (siamés `lost_006`, perros
  `found_012/013` con fotos del alumno + SEED v8; el gris pasó a `found_014` y la
  siamesa recuperó el `006`). Desde SEED v12 los 3 casos viajan en el seed
  (`data/seed/reencuentros/renc_006` validada + `renc_012/013` pendientes,
  `upsert_reencuentro_seed()` en cada recarga): sobreviven a dormir/Cloud.
- REQ-UI-65 — Los avisos en reencuentros siguen en el carrusel con segunda etiqueta
  (ámbar "En revisión" / verde "Caso cerrado", mismos colores), incluidos los
  resueltos (`select_carousel_items(..., extra=...)`).

## 26. Reencuentros visibles + cerrados en fila (v1.23 25/09/2026, solo UI)

- REQ-UI-56 — Vista previa de los avisos elegidos bajo cada multiselect (miniaturas;
  el desplegable no previsualiza al pasar el cursor: límite honesto de Streamlit).
- REQ-UI-57 — Tarjeta unificada con marca ("Caso cerrado"/"En revisión") y pie
  interior ("Resuelve X", alineado por construcción); "Cómo fue" vacío con placeholder.
- REQ-UI-58 — Cerrados en horizontal, de 3 en 3 por fila (`st.columns`).

## 24. Misma pestaña, atrás, fechas admin e insignia XL (v1.21 25/09/2026, solo UI)

- REQ-UI-43 — Carrusel y contadores con `target="_self"`: misma pestaña si el
  navegador lo respeta; si Streamlit fuerza pestaña nueva, el enlace igual aterriza
  directo en el aviso (`?aviso=`).
- REQ-UI-44 — Historial del navegador: cada sección queda reflejada en `?s=` y
  `sync_page_from_url()` adopta la URL (atrás/adelante y deep-links); `?page=`
  antiguo migra solo; `?aviso=` sigue siendo de un solo uso sin interferir.
- REQ-UI-45 — El admin edita `date_reported` y `date_last_seen` (texto ISO, validado
  por `validate_aviso`, con traza) para ajustar la demo (p. ej. el chip semáforo).
- REQ-UI-46 — Insignia lateral XL (1.6rem) con flecha grande (110px).

## 20. Boli en el hueco + imagen admin contenida (v1.17 25/09/2026, solo UI)

- REQ-UI-24 — Al subir foto en Publicar, la columna izquierda crece y deja hueco abajo
  a la derecha: lo rellena un boli escribiendo trazos en bucle (`build_pen_html()` en
  `ui_home.py`, al final de la columna derecha, SOLO si hay foto o precarga). Formato
  alto (`min-height:240px`, SVG 300×150) hasta la altura de "Cómo lo perdiste", con fondo
  translúcido (`rgba(255,255,255,0.45)`) que deja ver el patrón de la web y sin marco
  (`border:none`, S83).
- REQ-UI-25 — La foto del visor del administrador no desborda el sidebar: `show_image()`
  con `width=220` (letterbox centrado, animal entero) + guarda CSS
  (`max-width:100%` a las imágenes del sidebar).

## 13. Decisiones cerradas 23/09/2026 (13/13 — bloquean inicio de código)

1. Stack: Streamlit + Python + SQLite, 100% local. ✅
2. `image_embedding`: CLIP `openai/clip-vit-base-patch32`, 512-dim. ✅
3. `similitud_texto`: 70% estructurado (`color_primary`, `markings`, `has_collar`, `size`) + 30% semántico (`paraphrase-multilingual-MiniLM-L12-v2` sobre `description_text`). ✅
4. `proximidad_temporal`: `max(0, 1 - dias/30)`, ventana 30d, fecha = `date_last_seen` si existe si no `date_reported`. ✅
5. `radio_máximo`: 15 km fijos. ✅
6. Umbrales: `>=` en ambos (85 y 65). ✅
7. Ubicación: mapa Leaflet clicable + seed Jerez de la Frontera. ✅
8. `image_url`: ruta local `data/seed/images/`. ✅
9. Notifier: panel/tabla Streamlit + log, sin Telegram. ✅
10. Conflicto: manda Vision para `color_primary`; `description_text` intacto. ✅
11. `status`: botón "Marcar como resuelto" + `expire_old()` 365d bajo demanda, sin cron (v1.26, antes 30d). ✅
12. `other`: obligatorios `color_primary`, `size`, `description_text`; opcionales `markings`, `has_collar`; `breed_guess` NULL. ✅
13. Idioma: solo español. ✅

## 41. Implementación final — modos visuales, demo y seed (v1.41 05/10/2026)

- **Visión híbrida**: modo Local utiliza CLIP 512-d con PyTorch/Transformers; modo Streamlit Cloud, limitado a alrededor de 1 GB RAM, utiliza MobileNetV3-Small exportado a ONNX (576-d, ~10 MB RAM). Histograma RGB 8³ y hash quedan como fallbacks de último recurso. Query y candidatos siempre comparten el mismo espacio.
- **Búsqueda de demo**: para que el seed estático no pierda score temporal cada día, las queries de Buscar usan como fecha de referencia `2026-09-25T12:00:00+02:00` (último día del seed). Los avisos que se publican conservan fecha real de publicación y permiten elegir cuándo ocurrió la pérdida/avistamiento.
- **Lenguaje**: pesos de matching sin cambios. `raiz_es`/`raiz_frase` normalizan diminutivos, género y plural en colores, marcas y fallbacks TF-IDF/Jaccard (`gatito`/`gato`, `manchitas`/`mancha`); MiniLM local continúa usando el texto original.
- **Seed persistente**: v15, 20 avisos (6 lost + 14 found; 19 activos y 1 resuelto) y 3 reencuentros de demo versionados. `make_seed.py` es la fuente única; carga de seed y estados validados comprobados desde SQLite vacía.
- **UX**: Buscar es la única sección que calcula coincidencias; Publicar registra y usa fecha elegible. Los casos validados desaparecen de Perdidos/Avistamientos pero continúan etiquetados en el carrusel; mapas sin clustering.
- **Verificación de referencia**: 121 tests, `eval_match.py`, `demo_check.py` (found_011 top-1 80.5%) y `smoke_app.py` (9 páginas).
